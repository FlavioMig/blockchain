# dio-blockchain-for-devs

## Instalar o NodeJS com NPM: https://nodejs.org/en/download/

## Instalar o VS Code: https://code.visualstudio.com/download

## Instalar os pacotes do NPM: npm i

## Instalar o Framework Truffle: npm i -g truffle

## Download do Ganache: https://trufflesuite.com/ganache/

## Instalação do Metamask: https://chrome.google.com/webstore/detail/metamask/nkbihfbeogaeaoehlefnkodbefgpgknn?hl=en

